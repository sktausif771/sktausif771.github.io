--━━━━━━━━━━━━━━━━━━━━━━━
-- 💎 TAUSIF MODZ PC LOGO SCRIPT 👑
--━━━━━━━━━━━━━━━━━━━━━━━

--━━━━━━━━━━━━━━━━━━━━━━━
-- ⚡ MEMORY PATCH FUNCTION
--━━━━━━━━━━━━━━━━━━━━━━━
function MemoryPatcher(lib, offset, hex)
    local info = gg.getTargetInfo()
    local path = info.nativeLibraryDir
    local ranges = gg.getRangesList(path.."/lib"..lib)

    for _, v in ipairs(ranges) do
        local check = gg.getValues({
            {address = v.start, flags = gg.TYPE_DWORD}
        })

        if check[1].value == 0x464C457F then
            local addr = v.start + offset
            local bytes = {}

            hex:gsub("..", function(x)
                table.insert(bytes, {
                    address = addr + #bytes,
                    flags = gg.TYPE_BYTE,
                    value = x .. "h"
                })
            end)

            gg.setValues(bytes)
        end
    end
end

--━━━━━━━━━━━━━━━━━━━━━━━
-- 🎮 UI SYSTEM
--━━━━━━━━━━━━━━━━━━━━━━━
local state = {
    pc = false
}

function fastToast(msg)
    gg.toast("💎 "..msg)
end

function menu()
    local choice = gg.choice({
        (state.pc and "✅ " or "❌ ").."🖥️ PC Logo / ",
        "ℹ️ Script Info /",
        "🚪 Exit / "
    }, nil, "💎 TAUSIF MODZ PC LOGO PANEL 👑")

    if choice == 1 then
        if not state.pc then
            gg.toast("⚡ Activating... / ")
            gg.sleep(1000)

            MemoryPatcher("il2cpp.so", 0x41c6068, "00008052C0035FD6")
            MemoryPatcher("il2cpp.so", 0x41c6208, "20008052C0035FD6")

            state.pc = true
            gg.sleep(500)
            gg.toast("🎉 PC Logo Activated / ")
        else
            fastToast("Already Enabled / مفعل مسبقاً ⚠️")
        end

    elseif choice == 2 then
        gg.alert("💎 TAUSIF MODZ\n\n👑 Developer: TELEGRAM - @Tausif_Modz\n⚡ Status: Premium Active\n📅 Expiry: OBB 53")

    elseif choice == 3 then
        gg.toast(" BAN UR ACCOUNT / ")
        os.exit()
    end
end

--━━━━━━━━━━━━━━━━━━━━━━━
-- 🔄 MAIN LOOP
--━━━━━━━━━━━━━━━━━━━━━━━
while true do
    if gg.isVisible() then
        gg.setVisible(false)
        menu()
    end
end
